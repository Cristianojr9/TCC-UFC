import TodoList from '../components/TodoList';
import './Home.css'

function Home() {
  return (
    <div className='todo-app'>
      <TodoList />
    </div>
  )
}

export default Home;