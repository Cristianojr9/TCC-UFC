import { useState, useEffect, useRef } from "react";
import PropTypes from 'prop-types';

function TodoForm({ edit, onSubmit }) {
  const [input, setInput] = useState('');

  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current.focus()
  })

  const handleChange = e => {
    setInput(e.target.value)
  }
 
  const handleSubmit = e => {
    e.preventDefault(); 

    console.time('submit');

    onSubmit({
      id: Math.floor(Math.random() * 10000),
      text: input
    })
    setInput('')

    console.timeEnd('submit');
  }

  return (
    <form className="todo-form" onSubmit={handleSubmit}>
      {edit ? (
        <>
          <input 
            placeholder='update your item'
            value={input}
            onChange={handleChange}
            name='text'
            ref={inputRef}
            className='todo-input edit'
          />
          <button onClick={handleSubmit} className='todo-button edit'>
            Update
          </button>
        </>
      ) : (
        <>
          <input 
            className="todo-input" 
            type='text' 
            placeholder="add a todo" 
            value={input} name='text' 
            onChange={handleChange} 
            ref={inputRef}
          />
          <button className="todo-button">add todo</button>
        </>
      )}
    </form>
  )
}

export default TodoForm;

TodoForm.propTypes = {
  edit: PropTypes.object,
  onSubmit: PropTypes.func
}