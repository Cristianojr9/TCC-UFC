import { useState } from 'react';
import PropTypes from 'prop-types';

import TodoForm from './TodoForm';
import Todo from './Todo'

function TodoList() {
  const [todos, setTodos] = useState([]);

  const addTodo = todo => {
    if(!todo.text) return

    const newTodos = [todo, ...todos]

    setTodos(newTodos)
  }

  const updateTodo = (todoId, newValue) => {
    console.time('update');

    if (!newValue.text) return

    setTodos(prev => prev.map(item => (item.id === todoId ? newValue : item)))

    console.timeEnd('update');
  }

  const removeTodo = id => {
    console.time('remove');

    const removeArr = [...todos].filter(todo => todo.id !== id);

    setTodos(removeArr)
    
    console.timeEnd('remove');
  }

  const completeTodo = id => {
    console.time('complete');

    let updateTodos = todos.map(todo => {
      if (todo.id === id) todo.isComplete = !todo.isComplete;

      return todo;
    });

    setTodos(updateTodos); 

    console.timeEnd('complete');
  }

  return (
    <div className='todo-list'>
      <h1>whats the plan for today?</h1>

      <TodoForm onSubmit={addTodo}/>

      <Todo 
        todos={todos} 
        completeTodo={completeTodo} 
        removeTodo={removeTodo} 
        updateTodo={updateTodo} 
      />
    </div>
  )
}

export default TodoList;

TodoList.prototype = {
  todos: PropTypes.array
}