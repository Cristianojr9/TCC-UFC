<template>
  <form class="todo-form" v-on:submit.prevent="handleSubmit">
    <div v-if="edit">
      <label for="editItem">
        <input
          class="todo-input"
          id="editItem"
          placeholder="update your item"
          v-model="input"
        />
      </label>
      <button
        class="todo-button edit"
        type="submit"
        v-on:click="handleSubmit"
      >Update
      </button>
    </div>
    <div v-else>
      <input
        class="todo-input"
        id="text"
        placeholder="add a new item"
        v-model="input"
      />
      <button
        class="todo-button"
        type="submit"
        v-on:click="handleSubmit"
      >add todo</button>
    </div>
  </form>
</template>

<script>

export default {
  name: 'TodoForm',
  props: {
    edit: {
      type: Object,
      required: false,
    },
    onSubmit: {
      type: Function,
      required: true,
    },
  },
  data() {
    return {
      input: '',
    };
  },
  methods: {
    handleSubmit(e) {
      e.preventDefault();

      this.onSubmit({
        id: Math.floor(Math.random() * 100),
        text: this.input,
        isComplete: false,
      });

      this.input = '';
    },
  },
};
</script>

<style>
  .todo-form {
    margin-bottom: 32px;
  }

  .todo-input {
    padding: 14px 32px 14px 16px;
    border-radius: 4px 0 0 4px;
    border: 2px solid #5d0cff;
    outline: none;
    width: 320px;
    background: transparent;
    color: #fff;
  }

  .todo-input::placeholder {
    color: #e2e2e2;
  }

  .todo-button {
    padding: 16px;
    border: none;
    border-radius: 0 4px 4px 0;
    cursor: pointer;
    outline: none;
    background: linear-gradient(
      90deg,
      rgba(93, 12, 255, 1) 0%,
      rgba(155, 0, 250, 1) 100%
    );
    color: #fff;
    text-transform: capitalize;
  }

  .todo-input.edit {
    border: 2px solid #149fff;
  }

</style>
