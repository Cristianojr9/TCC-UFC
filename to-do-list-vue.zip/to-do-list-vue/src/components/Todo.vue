<template>
  <div v-if="edit.id">
    <todo-form :edit="edit" :onSubmit="submitUpdate"/>
  </div>
  <div v-else class="todo-row" :class="{ 'todo-row complete': isComplete }">
    <div>
      {{ text }}
    </div>
    <div class='icons'>
      <button v-on:click="handleRemoveTodo">
        <i class="fa fa-trash delete-icon" aria-hidden="true" ></i>
      </button>
      <button v-on:click="setEdit">
        <i class="fa fa-edit edit-icon" aria-hidden="true"></i>
      </button>
    </div>
  </div>
</template>

<script>
import TodoForm from './TodoForm.vue';

export default {
  components: { TodoForm },
  name: 'TodoItem',
  props: {
    id: {
      type: Number,
      required: true,
    },
    text: {
      type: String,
      required: true,
    },
    completeTodo: {
      type: Function,
      required: true,
    },
    removeTodo: {
      type: Function,
      required: true,
    },
    updateTodo: {
      type: Function,
      required: true,
    },
  },
  data() {
    return {
      edit: {
        id: null,
        value: '',
      },
    };
  },
  computed: {
    isComplete() {
      return this.todo?.isComplete;
    },
  },
  methods: {
    submitUpdate(value) {
      this.updateTodo(this.edit.id, value);
      this.edit = {
        id: null,
        value: '',
      };
    },
    handleCompleteTodo() {
      this.completeTodo(this.id);
    },
    handleRemoveTodo() {
      this.removeTodo(this.id);
    },
    setEdit() {
      this.edit = {
        id: this.id,
        value: this.text,
      };
    },
  },
};
</script>

<style>
  .todo-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 4px auto;
    color: #fff;
    background: linear-gradient(
      90deg,
      rgba(255, 118, 20, 1) 0%,
      rgba(255, 84, 17, 1) 100%
    );

    padding: 16px;
    border-radius: 5px;
    width: 90%;
  }

  .todo-row:nth-child(4n + 1) {
    background: linear-gradient(
      90deg,
      rgba(93, 12, 255, 1) 0%,
      rgba(155, 0, 250, 1) 100%
    );
  }

  .todo-row:nth-child(4n + 2) {
    background: linear-gradient(
      90deg,
      rgba(255, 12, 241, 1) 0%,
      rgba(250, 0, 135, 1) 100%
    );
  }

  .todo-row:nth-child(4n + 3) {
    background: linear-gradient(
      90deg,
      rgba(20, 159, 255, 1) 0%,
      rgba(17, 122, 255, 1) 100%
    );
  }

  .icons {
    display: flex;
    align-items: center;
    font-size: 24px;
    cursor: pointer;
  }

  .icons button {
    background: transparent;
    border: none;
  }

  .delete-icon {
    margin-right: 5px;
    color: #fff;
  }

  .edit-icon {
    color: #fff;
  }

</style>
