<template>
  <div class="todo-list">
    <h1>whats the plan for today?</h1>

    <todo-form :onSubmit="addTodo" />

    <todo-item
      v-for="todo in todos"
      v-bind="todo"
      :key="todo.id"
      :complete-todo="completeTodo"
      :remove-todo="removeTodo"
      :update-todo="updateTodo"
    />
  </div>
</template>

<script>

import TodoItem from './Todo.vue';
import TodoForm from './TodoForm.vue';

export default {
  components: { TodoItem, TodoForm },
  name: 'TodoList',
  data() {
    return {
      todos: [],
    };
  },
  methods: {
    addTodo(todo) {
      console.time('add');
      if (!todo.text) return;

      const newTodos = [...this.todos, todo];

      this.todos = newTodos;
      console.timeEnd('add');
    },
    completeTodo(id) {
      console.time('complete');
      const updateTodo = this.todos.map((todo) => {
        if (this.todo.id === id) {
          this.todo.isComplete = !todo.isComplete;
        }
        return todo;
      });

      this.todos = updateTodo;
      console.timeEnd('complete');
    },
    removeTodo(id) {
      console.time('remove');

      const removeArr = [...this.todos].filter((todo) => todo.id !== id);

      this.todos = removeArr;
      console.timeEnd('remove');
    },
    updateTodo(todoId, newValue) {
      console.time('update');

      if (!newValue.text) return;

      this.todos.map((todo) => {
        if (todo.id === todoId) {
          // eslint-disable-next-line no-param-reassign
          todo.text = newValue.text;
        }
        return todo;
      });

      console.timeEnd('update');
    },
  },
};
</script>

<style>
  h1 {
    margin: 32px 0;
    color: #fff;
    font-size: 24px;
  }
</style>
