import { Component, Input } from '@angular/core';
import { faTrash, faEdit } from '@fortawesome/free-solid-svg-icons';

import { TodosService, Todo } from '../todos.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent {
  @Input('todo')
  todoProps!: Todo;

  faTrash = faTrash
  faEdit = faEdit

  public edit = { id: '', text: '' }

  constructor(private todosService: TodosService) {}

  setEdit(id: string, text: string) {
    this.edit.id = id
    this.edit.text = text
  }

  removeTodo() {
    console.time('removeTodo');
    this.todosService.removeTodo(this.todoProps.id);
    console.timeEnd('removeTodo');
  }
}
