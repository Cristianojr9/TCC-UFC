import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { Todo, TodosService } from '../todos.service';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})

export class TodoListComponent {
  todosList$: Observable<Todo[]>;

  constructor(private todosService: TodosService) {
    this.todosList$ = this.todosService.todos$;
  }
}
