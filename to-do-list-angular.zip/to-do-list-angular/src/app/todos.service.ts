import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface Todo {
  id: string;
  text: string;
  isComplete: boolean;
}

@Injectable({
  providedIn: 'root'
})

export class TodosService {
  todos$ = new BehaviorSubject<Todo[]>([]);

  addTodo(text: string) {
    console.time('addTodo')
    const newTodo: Todo = {
      text,
      isComplete: false,
      id: Math.random().toString(16)
    }

    const updatedTodos = [...this.todos$.getValue(), newTodo];
    this.todos$.next(updatedTodos);

    console.timeEnd('addTodo')
  }

  removeTodo(id: string): void {
    console.time('removeTodo')

    const updatedTodos = this.todos$
      .getValue()
      .filter((todo) => todo.id !== id);

    this.todos$.next(updatedTodos);

    console.timeEnd('removeTodo')
  }
}
