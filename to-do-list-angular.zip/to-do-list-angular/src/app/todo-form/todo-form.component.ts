import { Component, Input } from '@angular/core';

import { TodosService, Todo } from '../todos.service';

@Component({
  selector: 'app-todo-form',
  templateUrl: './todo-form.component.html',
  styleUrls: ['./todo-form.component.css']
})

export class TodoFormComponent {
  @Input('todo')
  todoProps!: Todo;
  @Input()
  edit!: { id: string, text: string };
  public text = ''

  constructor(public todosService: TodosService) {}

  handleSubmit() {
    this.todosService.addTodo(this.text);
    this.text = ''
  }

  removeTodo(): void {
    console.log('removeTodo');
    this.todosService.removeTodo(this.todoProps.id);
  }
}
